# Conquerors-Assistant-Bot
Official discord bot for Task Force "Conquerors" BRM5 Faction
